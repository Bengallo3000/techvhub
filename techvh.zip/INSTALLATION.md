# TechVerseHub Installation Guide

## System Requirements
- Node.js 16+ 
- npm or yarn
- MongoDB
- Git

## Installation Steps

### 1. Install Node.js

**Windows:**
1. Download from https://nodejs.org/
2. Run installer
3. Restart terminal

**Ubuntu Linux:**
```bash
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs
```

### 2. Install MongoDB

**Windows:**
1. Download from https://www.mongodb.com/try/download/community
2. Run installer
3. Start MongoDB service

**Ubuntu Linux:**
```bash
sudo apt-get install mongodb
sudo systemctl start mongodb
```

### 3. Setup Backend

```bash
cd backend
npm install
cp .env.example .env
# Edit .env with your configuration
npm run dev
```

### 4. Setup Frontend

```bash
cd frontend
npm install
npm start
```

### 5. Setup Telegram Bot

```bash
cd telegram-bot
npm install
# Edit .env with your bot token
node bot.js
```

## Environment Configuration

Edit `backend/.env` with:
- MongoDB connection string
- JWT secret key
- Telegram bot token
- Stripe API keys
- Admin chat ID

## Running the Application

1. Start MongoDB
2. Start backend: `cd backend && npm run dev`
3. Start frontend: `cd frontend && npm start`
4. Start Telegram bot: `cd telegram-bot && node bot.js`

Access the application at http://localhost:3000