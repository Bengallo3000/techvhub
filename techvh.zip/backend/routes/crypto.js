const express = require('express');
const axios = require('axios');
const router = express.Router();

// Crypto-Preis umrechnen
router.post('/convert', async (req, res) => {
  try {
    const { amount, currency } = req.body;
    
    // Hole Crypto-Preise von CoinGecko
    const response = await axios.get('https://api.coingecko.com/api/v3/simple/price', {
      params: {
        ids: 'bitcoin,ethereum,litecoin',
        vs_currencies: 'eur,usd'
      }
    });

    const cryptoPrices = response.data;
    
    // Rechne um
    const conversions = {
      bitcoin: amount / cryptoPrices.bitcoin.eur,
      ethereum: amount / cryptoPrices.ethereum.eur,
      litecoin: amount / cryptoPrices.litecoin.eur
    };

    res.json({ conversions, cryptoPrices });
  } catch (error) {
    res.status(500).json({ error: 'Konvertierung fehlgeschlagen' });
  }
});

// Webhook-Endpunkt für Zahlungsbestätigungen
router.post('/webhook/crypto', (req, res) => {
  const { transactionId, status, amount, currency } = req.body;
  
  if (status === 'confirmed') {
    // Bestellung als bezahlt markieren
    updateOrderStatus(transactionId, 'paid');
    
    // Telegram Benachrichtigung
    sendTelegramMessage(`💰 Crypto-Zahlung erhalten: ${amount} ${currency}`);
  }
  
  res.status(200).send('OK');
});

// Helper functions (would be implemented elsewhere)
function updateOrderStatus(orderId, status) {
  // Implementation to update order status in database
  console.log(`Updating order ${orderId} to status: ${status}`);
}

function sendTelegramMessage(message) {
  // Implementation to send Telegram message
  console.log(`Telegram message: ${message}`);
}

module.exports = router;