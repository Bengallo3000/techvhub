import React, { useState } from 'react';

function Cart() {
  const [cartItems, setCartItems] = useState([]);

  const getTotal = () => {
    return cartItems.reduce((total, item) => total + item.price * item.quantity, 0);
  };

  return (
    <div className="cart">
      <h1>Warenkorb</h1>
      {cartItems.length === 0 ? (
        <p>Dein Warenkorb ist leer</p>
      ) : (
        <>
          <div className="cart-items">
            {cartItems.map(item => (
              <div key={item.id} className="cart-item">
                <img src={item.image} alt={item.name} />
                <div className="item-details">
                  <h3>{item.name}</h3>
                  <p>€{item.price}</p>
                </div>
                <div className="quantity">
                  <button>-</button>
                  <span>{item.quantity}</span>
                  <button>+</button>
                </div>
              </div>
            ))}
          </div>
          <div className="cart-total">
            <h3>Gesamt: €{getTotal()}</h3>
            <button>Zur Kasse</button>
          </div>
        </>
      )}
    </div>
  );
}

export default Cart;