import React from 'react';
import Banner from '../components/Banner';

function Home() {
  return (
    <div className="home">
      <Banner />
      <section className="hero">
        <h1>Willkommen bei TechVerseHub</h1>
        <p>Dein Shop für Tech-Produkte und kostenlose Apps</p>
      </section>
      
      <section className="featured-products">
        <h2>Beliebte Produkte</h2>
        {/* Product grid would go here */}
      </section>
    </div>
  );
}

export default Home;