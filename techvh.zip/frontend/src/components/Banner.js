import React, { useState, useEffect } from 'react';

function Banner() {
  const [banners, setBanners] = useState([]);

  useEffect(() => {
    // Banner von API holen
    fetch('/api/banners')
      .then(res => res.json())
      .then(data => setBanners(data));
  }, []);

  return (
    <div className="banner-carousel">
      {banners.map(banner => (
        <div key={banner.id} className="banner-slide">
          <img src={banner.imageUrl} alt={banner.title} />
          <div className="banner-content">
            <h3>{banner.title}</h3>
            <p>{banner.description}</p>
            <a href={banner.link} className="banner-btn">Jetzt entdecken</a>
          </div>
        </div>
      ))}
    </div>
  );
}

export default Banner;