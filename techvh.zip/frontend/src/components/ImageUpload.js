import React, { useState } from 'react';
import axios from 'axios';

function ImageUpload({ onImageUpload }) {
  const [uploading, setUploading] = useState(false);

  const handleUpload = async (e) => {
    const file = e.target.files[0];
    const formData = new FormData();
    formData.append('image', file);
    
    setUploading(true);
    try {
      const response = await axios.post('/api/upload', formData);
      onImageUpload(response.data.imageUrl);
    } catch (error) {
      console.error('Upload fehlgeschlagen:', error);
    }
    setUploading(false);
  };

  return (
    <div className="image-upload">
      <input type="file" accept="image/*" onChange={handleUpload} />
      {uploading && <p>Upload läuft...</p>}
    </div>
  );
}

export default ImageUpload;